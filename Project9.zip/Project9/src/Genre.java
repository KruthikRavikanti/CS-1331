/**
 * Genre enum.
 * @author kravikanti3
 * @version 1.0
 */
public enum Genre {
    ACTION, COMEDY, FANTASY, HORROR, MYSTERY, ROMANCE, SCI_FI;
}
