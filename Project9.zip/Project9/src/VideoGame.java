/**
 * VideoGame class.
 * @author kravikanti3
 * @version 1.0
 */
public class VideoGame extends Media {
    private int maxPlayers;

    /**
     * Getter method that says if the video game needs a console.
     * @return needsConsole as a boolean.
     */
    public boolean isNeedsConsole() {
        return needsConsole;
    }


    private boolean needsConsole;

    /**
     * Constructor that instantiates a video game object.
     * @param genre Genre of video game object.
     * @param name Name of video game object.
     * @param rating Rating of video game object.
     * @param rentalPrice Rental price of video game object.
     * @param maxPlayers Max player allowed in the video game object.
     * @param needsConsole Console need for video game object.
     */
    public VideoGame(Genre genre, String name, int rating, double rentalPrice, int maxPlayers, boolean needsConsole) {
        super(genre, name, rating, rentalPrice);
        this.needsConsole = needsConsole;
        this.maxPlayers = maxPlayers;
    }

    /**
     * Constructor that instantiates a video game object.
     * @param genre Genre of video game object.
     * @param name Name of video game object.
     * @param rating Rating of video game object.
     */
    public VideoGame(Genre genre, String name, int rating) {
        super(genre, name, rating, 5);
        this.maxPlayers = 2;
        this.needsConsole = false;
    }

    /**
     * Method that is a representation of the VideoGame reference.
     * @return String for above purpose.
     */
    @Override
    public String toString() {
        if (needsConsole) {
            return String.format("This is a %d-player %s video game called %s that needs a gaming console to play.",
                                maxPlayers, getGenre(), getName());
        } else {
            return String.format("This is a %d-player %s video game called %s that does not need a gaming console to"
                                + " play.", maxPlayers, getGenre(), getName());
        }
    }

    /**
     * Equals method that compares two VideoGame objects for specific attributes.
     * @param o The specified object taken in.
     * @return boolean True representing equal and false representing otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!(this.getClass().equals(o.getClass()))) {
            return false;
        }
        VideoGame n = (VideoGame) o;
        return super.equals(n) && maxPlayers == n.maxPlayers && needsConsole == n.needsConsole;
    }
}
