import java.util.ArrayList;
/**
 * Olivia class.
 * @author kravikanti3
 * @version 1.0
 */
public class Olivia {

    private static double budget;

    private static ArrayList<Media> cart;

    private static boolean canUseConsole;

    /**
     * Method that adds a particular media to the car if it is in the store.
     * @param m Media item wanting to be added.
     * @param b Blockbuster store where shopping is being done at.
     * @return A boolean is returned to see if desired Media item was found and added.
     */
    public static boolean addToCart(Media m, Blockbuster b) {
        if (budget < m.getRentalPrice()) {
            return false;
        }
        if (b.findMedia(m) == null) {
            return false;
        }
        if (b.findMedia(m) instanceof VideoGame) {
            VideoGame v = (VideoGame) b.findMedia(m);
            if (v.isNeedsConsole() && !canUseConsole) {
                return false;
            }
        }


        Media rI = b.removeMedia(m);
        cart.add(rI);
        budget -= rI.getRentalPrice();
        return true;
    }

    /**
     * Method that changes the persons mind about an item.
     * @param m The item that mind was changed to.
     * @param b Bockbuster store of interest.
     */
    public static void changeMind(Media m, Blockbuster b) {
        budget += m.getRentalPrice();
        for (int i = 0; i < cart.size(); i++) {
            if (m.equals(cart.get(i))) {
                b.getMediaItems().add(cart.get(i));
                cart.remove(m);
            }
        }
    }

    /**
     * Method that gives the budget of Olivia.
     * @return A double showing budget.
     */
    public static double getBudget() {
        return budget;
    }

    /**
     * Method that gives the cart.
     * @return ArrayList of cart returned.
     */
    public static ArrayList<Media> getCart() {
        return cart;
    }

    /**
     * Method shows if the media item can use console.
     * @return Returns a boolean.
     */
    public static boolean isCanUseConsole() {
        return canUseConsole;
    }

}
