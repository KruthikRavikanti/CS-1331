/**
 * Media class.
 * @author kravikanti3
 * @version 1.0
 */
public abstract class Media implements Comparable<Media> {
    private Genre genre;
    private String name;
    private int rating;
    private double rentalPrice;

    /**
     * Constructor that helps child classes initialize instance data.
     * @param genre Genre of a specific object.
     * @param name Name of the specific object.
     * @param rating Rating of the specific object.
     * @param rentalPrice Rental price of the specific object.
     */
    public Media(Genre genre, String name, int rating, double rentalPrice) {
        this.genre = genre;
        this.name = name;
        this.rating = rating;
        this.rentalPrice = rentalPrice;
    }

    /**
     * Constructor that helps child classes initialize instance data.
     * @param genre Genre of a specific object.
     * @param name Name of the specific object.
     * @param rating Rating of the specific object.
     */
    public Media(Genre genre, String name, int rating) {
        this(genre, name, rating, 7);
    }

    /**
     * Method that is a representation of the Media reference.
     * @return String for above purpose.
     */
    @Override
    public String toString() {
        return String.format("Genre: %s, Name: %s, Rating: %d, Rental Price: $%.2f", genre, name, rating, rentalPrice);
    }

    /**
     * Equals method that compares two Media references for specific attributes.
     * @param o The specified object taken in.
     * @return boolean True representing equal and false representing otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!(this.getClass().equals(o.getClass()))) {
            return false;
        }
        Media n = (Media) o;
        return name.equals(n.name) && rating == n.rating && rentalPrice == n.rentalPrice && genre.equals(n.genre);
    }

    /**
     * Method that compares Media objects with others in a specific way.
     * @param o the object to be compared.
     * @return An int showing the number representing a specific comparison.
     */
    @Override
    public int compareTo(Media o) {
        if (o == null) {
            return 1;
        }
        Integer current = genre.ordinal();
        Integer other = o.genre.ordinal();
        Integer current1 = rating;
        Integer other1 = o.rating;
        int b = current.compareTo(other);
        int i = name.compareTo(o.name);
        int j = current1.compareTo(other1);
        if (b != 0) {
            return b;
        } else if (i != 0) {
            return i;
        } else {
            return j;
        }
    }

    /**
     * Getter method that returns genre.
     * @return Genre is returned.
     */
    public Genre getGenre() {
        return genre;
    }

    /**
     * Getter method for name.
     * @return Name is returned.
     */
    public String getName() {
        return name;
    }

    /**
     * Getter method to return rating.
     * @return Rating is returned.
     */
    public int getRating() {
        return rating;
    }

    /**
     * Getter method to return rental price.
     * @return Rental price is returned.
     */
    public double getRentalPrice() {
        return rentalPrice;
    }
}
