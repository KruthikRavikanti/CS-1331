import java.util.ArrayList;
/**
 * Blockbuster class.
 * @author kravikanti3
 * @version 1.0
 */
public class Blockbuster {
    private ArrayList<Media> mediaItems;

    /**
     * Constructor that takes in no parameters and makes a blockbuster store.
     */
    public Blockbuster() {
        this.mediaItems = new ArrayList<>();
    }

    /**
     * A media is added to media items.
     * @param o The media to be added.
     */
    public void addMedia(Media o) {
        mediaItems.add(o);
    }

    /**
     * A particular media object is removed from mediaItems.
     * @param i Media to be removed.
     * @return The media that was removed from the array list.
     */
    public Media removeMedia(Media i) {
        int in = mediaItems.indexOf(i);
        if (!(mediaItems.contains(i))) {
            return null;
        } else if (mediaItems.get(in).equals(i)) {
            return mediaItems.remove(in);
        }
        return null;
    }

    /**
     * This method sorts the media objects in order according to the compareTo method.
     */
    public void sortMedia() {
        int size = mediaItems.size();
        for (int i = 0; i < size; i++) {
            Media min = mediaItems.get(i);
            for (int j = i; j < size; j++) {
                int m = min.compareTo(mediaItems.get(j));
                if (m > 0) {
                    mediaItems.set(i, mediaItems.get(j));
                    mediaItems.set(j, min);
                }
            }
        }
    }

    /**
     * Method that finds a particular media of interest.
     * @param m The media to be found.
     * @return The media that is returned based on what is found.
     */
    public Media findMedia(Media m) {
        this.sortMedia();
        int max = mediaItems.size() - 1;
        int middle = 0;
        int mini = 0;
        boolean status = false;
        while (!status && mini <= max) {
            middle = (mini + max) / 2;
            if (mediaItems.get(middle).compareTo(m) == 0) {
                status = true;
            } else if (mediaItems.get(middle).compareTo(m) < 0) {
                mini = middle + 1;
            } else {
                max = middle - 1;
            }
        }
        if (status) {
            return mediaItems.get(middle);
        } else {
            return null;
        }
    }

    /**
     * Method that lets the user know what the most popular movie is.
     * @return The description with the name of the most popular movie is returned.
     */
    public String mostPopularMovie() {
        if (mediaItems.isEmpty()) {
            return "No movies were found.";
        }
        Movie mostPop = null;
        for (Media media : mediaItems) {
            if (media instanceof Movie) {
                Movie m = (Movie) media;
                if (mostPop == null || m.getRating() > mostPop.getRating()
                        || (m.getRating() == mostPop.getRating()
                        && m.getName().compareTo(mostPop.getName()) < 0)) {
                    mostPop = m;
                }
            }
        }

        if (mostPop != null) {
            return String.format("With a rating of %d, our customers enjoy watching %s the most!",
                                mostPop.getRating(), mostPop.getName());
        }


        return "No movies were found.";
    }

    /**
     * Method that gets the mediaItems array list.
     * @return The array list is returned.
     */
    public ArrayList<Media> getMediaItems() {
        return mediaItems;
    }
}
