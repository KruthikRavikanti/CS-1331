/**
 * Movie class.
 * @author kravikanti3
 * @version 1.0
 */
public class Movie extends Media {
    private int runtime;

    /**
     * Constructor that instantiates a Movie object.
     * @param genre Genre of movie object.
     * @param name Name of movie object.
     * @param rating Rating of movie object.
     * @param rentalPrice Rental price of movie object.
     * @param runtime Runtime of movie object.
     */
    public Movie(Genre genre, String name, int rating, double rentalPrice, int runtime) {
        super(genre, name, rating, rentalPrice);
        this.runtime = runtime;
    }

    /**
     * Constructor that instantiates a Movie object.
     * @param genre Genre of movie object.
     * @param name Name of movie object.
     * @param rating Rating of movie object.
     */
    public Movie(Genre genre, String name, int rating) {
        super(genre, name, rating, 5);
        this.runtime = 111;
    }

    /**
     * Method that is a representation of the Movie reference.
     * @return String for above purpose.
     */
    @Override
    public String toString() {
        return String.format("Genre: %s, Name: %s, Rating: %d, Rental Price: $%.2f, Runtime: %d",
                            getGenre(), getName(), getRating(), getRentalPrice(), runtime);
    }

    /**
     * Equals method that compares two Movie objects for specific attributes.
     * @param o The specified object taken in.
     * @return boolean True representing equal and false representing otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!(this.getClass().equals(o.getClass()))) {
            return false;
        }
        Movie n = (Movie) o;
        return super.equals(n) && runtime == n.runtime;
    }
}
