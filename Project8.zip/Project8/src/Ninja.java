/**
 * Ninja class.
 * @author kravikanti3
 * @version 1.0
 */
public abstract class Ninja implements Comparable<Ninja> {

    private String name;

    /**
     * Getter method for an attribute.
     * @return An int is returned as health.
     */
    public int getHealth() {
        return health;
    }

    private int health;

    /**
     * Getter method for an attribute.
     * @return A String is returned for the name of the ninja.
     */
    public String getName() {
        return name;
    }

    /**
     * Getter method for an attribute.
     * @return A int is returned as the attack.
     */
    public int getAttack() {
        return attack;
    }

    private int attack;

    /**
     * Constructor used to make an object for subclasses.
     * @param name Name of ninja.
     * @param health Health of ninja.
     * @param attack Attack of nijnja.
     */
    public Ninja(String name, int health, int attack) {
        this.name = !(name == null && name.trim().equals("")) ? name : "Naruto Uzmaki";
        this.health = health > 0 ? health : 1;
        this.attack = attack >= 2 ? attack : 2;
    }

    /**
     * Method that shows if a ninja is fainted or not.
     * @return Boolean to show if ninja is fainted.
     */
    public boolean hasFainted() {
        return !(health > 0);
    }

    /**
     * Method that reduces a ninja's health based on the attack received.
     * @param attackDam The damage of an attack that needs to be used.
     */
    public void getAttacked(int attackDam) {
        health -= attackDam;
    }

    /**
     * Method that initiates a attack.
     * @param toBeAttacked Which ninja is being attacked.
     */
    public void attackNinja(Ninja toBeAttacked) {
        toBeAttacked.getAttacked(attack);
    }

    /**
     * Method that is a representation of the Ninja reference.
     * @return String for above purpose.
     */
    @Override
    public String toString() {
        String s = String.format("%s/%d/%d", name, attack, health);
        return s;
    }

    /**
     * Method that comapres ninja objects with others in a specific way.
     * @param o the object to be compared.
     * @return An int showing the number representing a specific comparsion.
     */
    @Override
    public int compareTo(Ninja o) {
        if (o == null) {
            return 1;
        } else if (!(attack + health <= o.getAttack() + o.getHealth())) {
            return 1;
        } else if (attack + health == o.getAttack() + o.getHealth()) {
            return 0;
        } else {
            return -1;
        }
    }
}