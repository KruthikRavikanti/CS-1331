/**
 * StoneNinja class.
 * @author kravikanti3
 * @version 1.0
 */
public class StoneNinja extends Ninja {
    private boolean ninjaArmor;

    /**
     * Constructor that makes a StoneNinja object.
     * @param name Name of ninja.
     * @param health Health of ninja.
     * @param attack Attack of ninja.
     * @param ninjaArmor If the ninja has armor or not.
     */
    public StoneNinja(String name, int health, int attack, boolean ninjaArmor) {
        super(name, health, attack);
        this.ninjaArmor = ninjaArmor;
    }

    /**
     * Constructor that makes a StoneNinja object without any paramters.
     */
    public StoneNinja() {
        super("Naruto Uzumaki", 8, 10);
        this.ninjaArmor = true;
    }

    /**
     * Method that breaks the ninja's armor as needed.
     */
    public void breakArmor() {
        ninjaArmor = false;
    }

    /**
     * Method that is a representation of the StoneNinja object.
     * @return String for above purpose.
     */
    @Override
    public String toString() {
        return String.format("Stone Ninja: %s/%d/%d/%b", getName(), getAttack(), getHealth(), ninjaArmor);
    }

    /**
     * Method that reduces a ninja's health based on the attack received.
     * @param attackDa The damage of an attack that needs to be used.
     */
    @Override
    public void getAttacked(int attackDa) {
        if (ninjaArmor) {
            attackDa = (attackDa - 20 < 0) ? 0 : 20;
            super.getAttacked(attackDa);
            ninjaArmor = false;
        } else {
            super.getAttacked(attackDa);
        }
    }
}
