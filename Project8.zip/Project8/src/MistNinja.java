/**
 * MistNinja class.
 * @author kravikanti3
 * @version 1.0
 */
public class MistNinja extends Ninja {
    private int hitChance;

    /**
     * Constructor that makes a MistNinja object.
     * @param name Name of ninja.
     * @param health Health of ninja.
     * @param attack Attack of ninja.
     * @param hitChance Chance of being hit by this ninja.
     */
    public MistNinja(String name, int health, int attack, int hitChance) {
        super(name, health, attack);
        this.hitChance = !(hitChance < 5 && hitChance > 15) ? hitChance : 12;
    }

    /**
     * Constructor that makes a MistNinja object without any paramters.
     */
    public MistNinja() {
        super("Naruto Uzumaki", 7, 8);
        this.hitChance = 12;
    }

    /**
     * Method that is unique of ths MistNinja object.
     */
    public void getConfused() {
        hitChance = (hitChance + 1 >= 5 && hitChance + 1 <= 15) ? hitChance + 1 : hitChance;
    }

    /**
     * Method that reduces a ninja's health based on the attack received.
     * @param attackDa The damage of an attack that needs to be used.
     */
    @Override
    public void getAttacked(int attackDa) {
        if (attackDa % hitChance != 0) {
            super.getAttacked(attackDa);
        }
    }

    /**
     * Method that is a representation of the MistNinja object.
     * @return String for above purpose.
     */
    @Override
    public String toString() {
        return String.format("Mist Ninja: %s/%d/%d/%d", getName(), getAttack(), getHealth(), hitChance);
    }
}
