/**
 * FifthGreatNinjaWar class.
 * @author kravikanti3
 * @version 1.0
 */
public class FifthGreatNinjaWar {
    private Ninja[] firstTeam;
    private Ninja[] secondTeam;

    /**
     * Constructor making a FifthGreatNinjaWar object with a couple of paramters.
     * @param firstTeam Ninja object array.
     * @param secondTeam Ninja object array.
     */
    public FifthGreatNinjaWar(Ninja[] firstTeam, Ninja[] secondTeam) {
        if (secondTeam.length != 5 || firstTeam.length != 5) {
            this.firstTeam = new Ninja[5];
            this.secondTeam = new Ninja[5];
        } else {
            this.firstTeam = firstTeam;
            this.secondTeam = secondTeam;
        }
    }

    /**
     * Method that compares teams based on null indices and strength at a index.
     */
    public void compareTeams() {
        int cT0 = 0, cTT = 0;
        for (int j = 0; j < firstTeam.length; j++) {
            if (firstTeam[j] != null && firstTeam[j].compareTo(secondTeam[j]) > 0) {
                cT0 += 1;
            } else if (secondTeam[j] != null && secondTeam[j].compareTo(firstTeam[j]) > 0) {
                cTT += 1;
            }
        }

        if (cT0 > cTT) {
            System.out.println("The first team will probably win.");
        } else if (cT0 == cTT) {
            System.out.println("It is an even match.");
        } else {
            System.out.println("The second team will probably win.");
        }
    }

    /**
     * Method that performs the battle of both teams and declares the winning team.
     */
    public void battle() {
        int team1 = 0, team2 = 0;
        for (int i = 0; i < 5; i++) {
            if (firstTeam[i] == null) {
                team1 += 1;
            } else {
                break;
            }
        }

        for (int i = 0; i < 5; i++) {
            if (secondTeam[i] == null) {
                team2 += 1;
            } else {
                break;
            }
        }

        while (team1 < firstTeam.length && team2 < secondTeam.length) {
            if (firstTeam[team1] == null && secondTeam[team2] == null) {
                team1 += 1;
                team2 += 1;
            } else if (firstTeam[team1] == null && secondTeam[team2] != null) {
                team1 += 1;
            } else if (firstTeam[team1] != null && secondTeam[team2] == null) {
                team2 += 1;
            } else {
                firstTeam[team1].attackNinja(secondTeam[team2]);
                secondTeam[team2].attackNinja(firstTeam[team1]);
                boolean b = firstTeam[team1].hasFainted();
                firstTeam[team1] = b ? null : firstTeam[team1];
                team1 = b ? team1 + 1 : team1;
                boolean c = secondTeam[team2].hasFainted();
                secondTeam[team2] = c ? null : secondTeam[team2];
                team2 = c ? team2 + 1 : team2;
            }
        }

        if (team1 == 5 && team2 != 5) {
            System.out.println("The second team won!");
        } else if (team1 == 5) {
            System.out.println("Both teams fainted.");
        } else {
            System.out.println("The first team won!");
        }

    }

    /**
     * Method that represents the fifth great ninja war.
     * @return String showing each team and how they won.
     */
    public String toString() {
        String wRep = "First Team: ";
        for (int i = 0; i < firstTeam.length; i++) {
            if (i == 4) {
                if (firstTeam[i] == null) {
                    wRep += "Empty ";
                    break;
                } else {
                    wRep += firstTeam[i] + " ";
                    break;
                }
            }
            wRep = firstTeam[i] == null ? wRep + "Empty, " : wRep + firstTeam[i] + ", ";
        }

        wRep += "vs Second Team: ";
        for (int i = 0; i < secondTeam.length; i++) {
            if (i == 4) {
                if (secondTeam[i] == null) {
                    wRep += "Empty ";
                    break;
                } else {
                    wRep += secondTeam[i] + " ";
                    break;
                }
            }
            wRep = secondTeam[i] == null ? wRep + "Empty, " : wRep + secondTeam[i] + ", ";
        }

        return wRep;
    }


    /**
     * Main method that declares the needed objects to test the written code.
     * @param args Convention.
     */
    public static void main(String[] args) {
        Ninja nin1 = new StoneNinja();
        Ninja nin2 = new MistNinja("nah", 15, 16, 8);
        Ninja nin3 = new LeafNinja();
        Ninja nin4 = new MistNinja("ho", 5, 6, 10);
        StoneNinja nin5 = new StoneNinja();
        MistNinja nin6 = new MistNinja("nah", 15, 16, 8);
        LeafNinja nin7 = new LeafNinja();
        MistNinja nin8 = new MistNinja("ho", 5, 6, 10);
        Ninja[] t1 = {null, nin1, nin2, nin3, nin4};
        Ninja[] t2 = {nin5, nin6, nin6, nin7, nin8};
        FifthGreatNinjaWar huh = new FifthGreatNinjaWar(t1, t2);
        huh.battle();

    }

}
