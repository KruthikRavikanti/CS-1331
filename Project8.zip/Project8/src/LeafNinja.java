/**
 * LeafNinja class.
 * @author kravikanti3
 * @version 1.0
 */
public class LeafNinja extends Ninja {
    private int poisonAmount;

    /**
     * Constructor that makes a leaf ninja object.
     * @param name Name of the ninja.
     * @param health Health of the ninja.
     * @param attack Attack power of the ninja.
     * @param poisonAmount How much a ninja can poison.
     */
    public LeafNinja(String name, int health, int attack, int poisonAmount) {
        super(name, health, attack);
        this.poisonAmount = poisonAmount < 0 ? 5 : poisonAmount;
    }

    /**
     * Constructor that makes a leaf ninja object with no paramters.
     */
    public LeafNinja() {
        super("Naruto Uzumaki", 5, 9);
        this.poisonAmount = 10;
    }

    /**
     * Method that changes stats according to the carried out attack.
     * @param o A ninja object that performs the poison attack.
     */
    public void poisonAttack(Ninja o) {
        if (poisonAmount > 0) {
            if (o instanceof StoneNinja) {
                StoneNinja o1 = (StoneNinja) o;
                o1.breakArmor();
            } else if (o instanceof MistNinja) {
                MistNinja o1 = (MistNinja) o;
                o1.getConfused();
            } else if (o instanceof LeafNinja) {
                LeafNinja o1 = (LeafNinja) o;
                if (compareTo(o1) > 0) {
                    poisonAmount += 2;
                } else if (compareTo(o1) < 0) {
                    o1.poisonAmount += 2;
                }
            }
            poisonAmount -= 1;
        }
    }

    @Override
    public void attackNinja(Ninja o) {
        poisonAttack(o);
        if (poisonAmount == 0) {
            o.getAttacked(getAttack() / 2);
        } else {
            o.getAttacked(getAttack());
        }
    }

    /**
     * Method that is a representation of the LeafNinja object.
     * @return String for above purpose.
     */
    @Override
    public String toString() {
        return String.format("Leaf Ninja: %s/%d/%d/%d", getName(), getAttack(), getHealth(), poisonAmount);
    }
}
