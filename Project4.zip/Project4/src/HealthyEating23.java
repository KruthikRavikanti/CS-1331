public class HealthyEating23 {

    public static void main(String[] args) {
        Food[] meal1 = mealPrep(6);
        Food[] meal2 = mealPrep(6);
        mealAnalyzer(meal1);
        mealAnalyzer(meal2);
        healthyChoice(meal1, meal2);
        meal1 = followRecipe("GRAIN PROTEIN FRUIT VEGETABLE");
        meal2 = followRecipe("JUNK_FOOD DAIRY GRAIN PROTEIN");
        healthyChoice(meal1, meal2);
        meal1 = followRecipe("JUNK_FOOD DAIRY GRAIN PROTEIN");
        meal2 = followRecipe("GRAIN PROTEIN FRUIT VEGETABLE");
        healthyChoice(meal1, meal2);
        meal1 = followRecipe("PROTEIN FRUIT GRAIN FRUIT");
        meal2 = followRecipe("PROTEIN FRUIT GRAIN FRUIT");
        healthyChoice(meal1, meal2);
    }

    public static Food[] mealPrep(int numFoods) {
        Food[] foodArray = new Food[numFoods];
        for (int i = 0; i < numFoods; i++) {
            foodArray[i] = Food.values()[(int) (Math.random() * Food.values().length)];
        }
        return foodArray;
    }

    public static Food[] followRecipe(String recipe) {
        Food[] foodArray = new Food[recipe.split(" ").length];
        for (int i = 0; i < foodArray.length; i++) {
            foodArray[i] = Food.valueOf(recipe.split(" ")[i]);
        }
        return foodArray;
    }

    public static void mealAnalyzer(Food[] foodArray) {
        System.out.println("The following types of food are in your meal:");
        for (Food f : Food.values()) {
            System.out.print(f + " ");
            int num = 0;
            for (Food food : foodArray) {
                if (food == f) {
                    num++;
                }
            }
            System.out.println(num);
        }
    }

    public static void healthyChoice(Food[] meal1, Food[] meal2) {
        int meal1Score = 0, meal2Score = 0;
        for (Food f : meal1) {
            meal1Score += f.ordinal();
        }
        for (Food f : meal2) {
            meal2Score += f.ordinal();
        }
        if (meal1Score > meal2Score) {
            System.out.printf("The first meal is the healthier choice with a score of %d.\n", meal1Score);
        } else if (meal2Score > meal1Score) {
            System.out.printf("The second meal is the healthier choice with a score of %d.\n", meal2Score);
        } else {
            System.out.printf("The two meals are equally healthy with scores of %d.\n", meal1Score);
        }
    }
}