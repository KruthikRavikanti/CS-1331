public class Driver {
    public static void main(String[] args) {
        Card[] wario = new Card[3];
        Collection coll = new Collection(wario);
//        Collection coll = new Collection();
        Card first = new Card(50,"Jigglypuff",PokemonType.GROUND,"Hyperbeam",42);
        coll.addCard(0, first);
        Card second = new Card(60,"Pikachu", PokemonType.FIRE);
        coll.addCard(1, second);
        Card third = new Card();
        coll.addCard(2, third);
        coll.sellCard(2);
        String s = coll.toString();
        System.out.println(s);
        coll.showCertainCards(80);
        coll.restoreAllCards();
        coll.battle(1);
    }
}
