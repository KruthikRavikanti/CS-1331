public class Collection {
    private Card[] binder;
    private int cardsOwned;
    public Collection(Card[] binder) {
        this.binder = binder;
        this.cardsOwned = 0;
        for (Card card: binder) {
            if (card != null) {
                this.cardsOwned++;
            }
        }
    }
    public Collection() {
        this.binder = new Card[4];
        this.cardsOwned = 0;
    }
    public Card addCard(int index, Card card) {
        if (index >= this.binder.length || card == null || index < 0) {
            System.out.println("Cannot add a card to this spot.");
            return null;
        } else if (this.binder[index] == null) {
            this.cardsOwned++;
            this.binder[index] = card;
            System.out.println("Inserted: " + card.toString());
            return null;
        } else {
            Card s = this.binder[index];
            System.out.println("Replaced: " + this.binder[index]);
            this.binder[index] = card;
            return s;
        }
    }
    public Card sellCard(int index) {
        if (index >= this.binder.length || index < 0 || this.binder[index] == null) {
            System.out.println("There was no card to sell!");
            return null;
        } else {
            System.out.println("Sold: " + this.binder[index].toString());
            Card s = this.binder[index];
            this.binder[index] = null;
            this.cardsOwned--;
            return s;
        }
    }
    public void showCertainCards(int index) {
        if (index < this.binder.length && index >= 0) {
            for (int i = index; i < this.binder.length; i++) {
                System.out.println(this.binder[i]);
            }
        }
    }
    public void restoreAllCards() {
        int numberOfCardsRestored = 0;
        for (Card card : this.binder) {
            if (card != null && card.isRestorable()) {
                int newCondition = card.getCondition() + (int) (Math.random() * 10 + 1);
                System.out.printf("Restored to %d: %s\n", newCondition, card.toString());
                card.setCondition(newCondition);
                numberOfCardsRestored++;
            }
        }
        if (numberOfCardsRestored == 0) {
            System.out.println("There were no cards to restore.");
        }
    }

    public void battle(int index) {
        if (index >= this.binder.length || index < 0 || this.binder[index] == null) {
            System.out.println("Cannot battle with a card at this spot.");
        } else {
            int newCondition = this.binder[index].getCondition() - (int) (Math.random() * 10 + 1);
            this.binder[index].setCondition(newCondition < 40 ? 40 : newCondition);
            System.out.println("Used: " + this.binder[index]);
        }
    }

    public String toString() {
        String st = String.format("I own %d cards.", this.cardsOwned);
        int cardCounter = 0;
        for (Card card : this.binder) {
            if (card != null) {
                st += "\n" + card;
                cardCounter++;
            }
        }
        if (this.cardsOwned == 0) {
            st = "I own no cards!";
        }
        return st;
    }

}


















