public enum PokemonType {
    NORMAL, FIRE, WATER, GRASS, GROUND;
}
