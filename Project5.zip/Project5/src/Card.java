public class Card {
    private int hitPoints;
    private String pokemonName;
    private PokemonType pokemonType;
    private String attack;

    private int condition;

    public Card(int hitPoints, String pokemonName, PokemonType pokemonType, String attack, int condition) {
        this.hitPoints = hitPoints;
        this.pokemonName = pokemonName;
        this.pokemonType = pokemonType;
        this.attack = attack;

        if (condition >= 90 && condition <= 100) {
            this.condition = condition;
            System.out.println("Card condition: Mint");
        } else if (condition >= 80 && condition <= 89) {
            this.condition = condition;
            System.out.println("Card condition: Excellent");
        } else if (condition >= 70 && condition <= 79) {
            this.condition = condition;
            System.out.println("Card condition: Very Good");
        } else if (condition >= 60 && condition <= 69) {
            this.condition = condition;
            System.out.println("Card condition: Good");
        } else if (condition >= 50 && condition <= 59) {
            this.condition = condition;
            System.out.println("Card condition: Fine");
        } else if (condition >= 40 && condition <= 49) {
            this.condition = condition;
            System.out.println("Card condition: Damaged");
        } else {
            this.condition = 80;
            System.out.println("Card condition: Excellent");
        }
    }

    public Card(int hitPoints, String pokemonName, PokemonType pokemonType) {
        this.hitPoints = hitPoints;
        this.pokemonName = pokemonName;
        this.pokemonType = pokemonType;
        this.attack = "Hyperbeam";
        this.condition = 80;
        System.out.println("Card condition: Excellent");
    }

    public Card() {
        this.hitPoints = 120;
        this.pokemonName = "Ditto";
        this.pokemonType = PokemonType.NORMAL;
        this.attack = "Imposter";
        this.condition = 89;
        System.out.println("Card condition: Excellent");
    }

    public boolean isRestorable() {
        return this.condition >= 50 && this.condition <= 89;
    }

    public String toString() {
        String st = String.format("<%d,%s,%s,%s,%d,%b>", this.hitPoints, this.pokemonName,
                this.pokemonType, this.attack, this.condition, this.isRestorable());
        return st;
    }

    public int getCondition() {
        return condition;
    }

    public void setCondition(int condition) {
        this.condition = condition;
    }
}
