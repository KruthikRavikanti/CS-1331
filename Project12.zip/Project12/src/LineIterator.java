import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * LineIterator class.
 * @author kravikanti3
 * @version 1.0
 * @param <T> type input.
 */
public class LineIterator<T> implements Iterator<T> {
    private Person<T> nextPerson;

    /**
     * Constructor for the class line iterator.
     * @param line LIne that can be iterated with.
     */
    public LineIterator(Line<T> line) throws IllegalArgumentException {
        if (line == null) {
            throw new IllegalArgumentException();
        }
        this.nextPerson = line.getFirstPerson();

    }

    /**
     * Shows if a new person in line is there after.
     * @return A boolean is returned if another person exists in line.
     */
    @Override
    public boolean hasNext() {
        return !(nextPerson == null);
    }

    /**
     * Method that overrides the next of iterator.
     * @return THe parcel of the next person is returned.
     */
    @Override
    public T next() throws NoSuchElementException {
        if (!(nextPerson.getParcel() != null)) {
            throw new NoSuchElementException();
        }
        T par = nextPerson.getParcel();
        nextPerson = nextPerson.getNextPerson();
        return par;
    }
}
