/**
 * Person class.
 * @author kravikanti3
 * @version 1.0
 * @param <T> parameter generic type.
 */
public class Person<T> {

    /**
     * Method that gets parcel.
     * @return Parcel returned.
     */
    public T getParcel() {
        return parcel;
    }

    /**
     * Method that sets parcel as something.
     * @param parcel A parcelt o be set.
     */
    public void setParcel(T parcel) {
        this.parcel = parcel;
    }

    private T parcel;

    /**
     * Method that sets next person as something.
     * @param nextPerson Sets next person in line.
     */
    public void setNextPerson(Person<T> nextPerson) {
        this.nextPerson = nextPerson;
    }

    /**
     * Method gets next person.
     * @return Next person in line.
     */
    public Person<T> getNextPerson() {
        return nextPerson;
    }

    private Person<T> nextPerson;

    /**
     * Constructor takes in 2 paramters.
     * @param parcel Type T parcel.
     * @param nextPerson The next person of line.
     */
    public Person(T parcel, Person nextPerson) throws IllegalArgumentException {
        if (parcel == null) {
            throw new IllegalArgumentException("Don't make parcel null");
        }
        this.nextPerson = nextPerson;
        this.parcel = parcel;
    }

    /**
     * Constructor that just takes in parcel.
     * @param parcel Parcel is taken in.
     */
    public Person(T parcel) throws IllegalArgumentException {
        if (parcel == null) {
            throw new IllegalArgumentException("Parcel, why is it null?");
        }
        this.nextPerson = null;
        this.parcel = parcel;
    }
}
