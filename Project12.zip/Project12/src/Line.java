import java.util.Iterator;
import java.util.NoSuchElementException;
/**
 * Line class.
 * @author kravikanti3
 * @version 1.0
 * @param <T> type input Person carries.
 */
public class Line<T> implements List<T> {
    private Person<T> firstPerson;
    private int size;

    /**
     * Constructor taking a array in of parcels of type T.
     * @param parcel Array of parcel T type objects.
     */
    public Line(T[] parcel) throws IllegalArgumentException {
        if (parcel == null) {
            throw new IllegalArgumentException("Parcel array be null");
        }
        int x = parcel.length;
        if (!(x < 1)) {
            this.firstPerson = new Person<>(parcel[0]);
            Person<T> before = firstPerson;
            for (int i = 1; i < x; i++) {
                if (parcel[i] == null) {
                    throw new IllegalArgumentException("Array null element");
                }
                Person<T> noPO = new Person<>(parcel[i]);
                before.setNextPerson(noPO);
                before = noPO;
            }
        } else {
            this.firstPerson = null;
        }
        this.size = parcel.length;
    }

    /**
     * Constructor taking no parameters.
     */
    public Line() {
        this.firstPerson = null;
        this.size = 0;
    }

    /**
     * Method that returns first person in line.
     * @return First person in line.
     */
    public Person<T> getFirstPerson() {
        return firstPerson;
    }

    /**
     * Returns array of objects.
     * @return Parcel array objects.
     */
    public T[] toArray() {
        Iterator<T> iti = iterator();
        T[] ari = (T[]) new Object[size];
        int i = 0;
        while (i < size && iti.hasNext()) {
            ari[i] = iti.next();
            i += 1;
        }
        return ari;
    }

    /**
     * Method that returns description of this class's object.
     * @return String representation.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(
                String.format("===== LINE %d =====\nisEmpty: %b\nsize: %d\nfirstPerson: %s\n: [",
                        hashCode(),
                        isEmpty(),
                        size(),
                        (firstPerson == null ? "null" : firstPerson.getParcel())));
        T[] people = toArray();
        if (people == null) {
            sb.append("TODO: Implement toArray method...");
        } else {
            for (int i = 0; i < people.length - 1; ++i) {
                sb.append(String.format("%s, ", people[i])); // append all but last value
            }
            if (people.length > 0) {
                sb.append(String.format("%s", people[people.length - 1])); //append last value
            }
        }
        sb.append("]\n============================");
        return sb.toString();
    }


    /**
     * Adds person with parcel to line.
     * @param element the element we are adding to the list
     * @throws IllegalArgumentException Exception thrown.
     */
    @Override
    public void add(T element) throws IllegalArgumentException {
        if (element == null) {
            throw new IllegalArgumentException("Element is null :(");
        }
        if (firstPerson == null) {
            firstPerson = new Person<T>(element);
            size += 1;
        } else {
            Person<T> por = firstPerson;
            while (por.getNextPerson() != null) {
                por = por.getNextPerson();
            }
            Person<T> noPO = new Person<>(element);
            por.setNextPerson(noPO);
            size += 1;
        }
    }


    /**
     * Method that will add.
     * @param index the index to add the element at.
     * @param element the element we are adding to the list.
     * @throws IndexOutOfBoundsException Exception thrown.
     * @throws IllegalArgumentException Exception thrown.
     */
    @Override
    public void add(int index, T element) throws IndexOutOfBoundsException, IllegalArgumentException {
        int con = 0;
        if (!(index <= size) || index < 0) {
            throw new IndexOutOfBoundsException();
        }
        if (element == null) {
            throw new IllegalArgumentException();
        }
        if (index == 0 && size != 0) {
            this.firstPerson = new Person<>(element, firstPerson);
            size++;
        } else if (index == 0) {
            firstPerson = new Person<>(element);
            size++;
        } else {
            Person<T> curt = firstPerson;
            if (con != index - 1) {
                do {
                    con += 1;
                    curt = curt.getNextPerson();
                } while (con != index - 1);
            }
            curt.setNextPerson(new Person<T>(element, curt.getNextPerson()));
            size++;
        }
    }




    /**
     * Method that removes from list.
     * @return The person removed.
     */
    @Override
    public T remove() throws NoSuchElementException {
        if (firstPerson == null) {
            throw new NoSuchElementException();
        }
        T por = firstPerson.getParcel();
        firstPerson = firstPerson.getNextPerson();
        size--;
        return por;
    }


    /**
     * Method that takes in a index to removed that particular index.
     * @param index the index of the element to be removed.
     * @return The removed parcel.
     * @throws NoSuchElementException Exception thrown.
     * @throws IndexOutOfBoundsException Exception thrown.
     */
    @Override
    public T remove(int index) throws NoSuchElementException, IndexOutOfBoundsException {
        if (firstPerson == null) {
            throw new NoSuchElementException("Empty list");
        }
        if (index >= size || index < 0) {
            throw new IndexOutOfBoundsException("Out of bound index");
        }
        if (index == 0) {
            return remove();
        } else {
            int c = 0;
            Person<T> cur = firstPerson;
            while (!(c == index - 1)) {
                c++;
                cur = cur.getNextPerson();
            }
            Person<T> rem = cur.getNextPerson();
            cur.setNextPerson(rem.getNextPerson());
            rem.setNextPerson(null);
            size--;
            return rem.getParcel();
        }
    }


    /**
     * Method that will remove parameter..
     * @param element the element to be removed
     * @return Type T is returned.
     * @throws IllegalArgumentException Exception thrown.
     * @throws NoSuchElementException Exception thrown.
     */
    @Override
    public T remove(T element) throws IllegalArgumentException, NoSuchElementException {
        if (element == null) {
            throw new IllegalArgumentException("Null element");
        }
        Person<T> por = firstPerson;
        int j = 0;
        while (j < size) {
            if (por.getParcel().equals(element)) {
                return remove(j);
            } else {
                por = por.getNextPerson();
            }
            j++;
        }
        throw new NoSuchElementException("Not there.");
    }


    /**
     * Method to set the needed parameter.
     * @param index the index of the element to be replaced.
     * @param element the element that should replace the existing element at the passed in index.
     * @return Paramter T is returned.
     * @throws IndexOutOfBoundsException Exception thrown.
     * @throws IllegalArgumentException Exception thrown.
     */
    @Override
    public T set(int index, T element) throws IndexOutOfBoundsException, IllegalArgumentException {
        if (element == null) {
            throw new IllegalArgumentException("Null element");
        }
        if (!(index < size)) {
            throw new IndexOutOfBoundsException("Out of bounds index");
        } else {
            Person<T> pers = firstPerson;
            int j = 0;
            while (j < index) {
                pers = pers.getNextPerson();
                j++;
            }
            T p = pers.getParcel();
            pers.setParcel(element);
            return p;
        }
    }





    /**
     * Method that will get a particulat T.
     * @param index the index of the element to get.
     * @return A T is returned.
     * @throws IndexOutOfBoundsException Exception.
     */
    @Override
    public T get(int index) throws IndexOutOfBoundsException {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds!");
        }

        Iterator<T> iterator = iterator();
        int counter = 0;

        while (iterator.hasNext()) {
            T element = iterator.next();
            if (counter == index) {
                return element;
            }
            counter++;
        }

        throw new IndexOutOfBoundsException("Index " + index + " is out of bounds!");
    }


    /**
     * Method that will check contains.
     * @param element the element to search for in the list.
     * @return A boolean is returned.
     * @throws IllegalArgumentException Exception thrown.
     */
    @Override
    public boolean contains(T element) throws IllegalArgumentException {
        if (element == null) {
            throw new IllegalArgumentException();
        }
        for (T parcel : this) {
            if (parcel.equals(element)) {
                return true;
            }
        }
        return false;
    }









    /**
     * The list is cleared.
     */
    @Override
    public void clear() {
        size = 0;
        this.firstPerson = null;
    }

    /**
     * Method checks if line's empty.
     * @return boolean showing line is empty.
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Size of line is returned.
     * @return Size of line.
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * A ineIterator object is created.
     * @return iterator object.
     */
    @Override
    public Iterator<T> iterator() {
        return new LineIterator<>(this);
    }

    /**
     * The linked list is reversed.
     */
    public void reverse() {
        revHelper(firstPerson, null);
    }

    /**
     * Helper method that reverses the lsit in a recursive manner.
     * @param curr Head of the linkedlist to be reversed.
     * @param before New head of the list.
     */
    private void revHelper(Person<T> curr, Person<T> before) {
        if (curr == null) {
            firstPerson = before;
            return;
        }
        revHelper(curr.getNextPerson(), curr);
        curr.setNextPerson(before);
    }


}