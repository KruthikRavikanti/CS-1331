public class Kru {
    public static void main(String[] args) {
        String s = "Kruthik";
        stringy(s);
        System.out.println(s);
    }
    public static void stringy(String s) {
        s = "Rohan";
    }
}
