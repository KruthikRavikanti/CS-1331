/**
 * This Enum describes groups members may belong to.
 *
 * @author Your friendly CS1331 TAs
 * @version v-13.31
 */
public enum Group {
    FRONTEND,
    BACKEND,
    ADMIN
}