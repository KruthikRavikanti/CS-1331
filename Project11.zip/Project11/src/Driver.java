import java.util.ArrayList;

public class Driver {
    public static void main(String[] args) {
        // Add a getter and setter for Team.members for testing purposes. Make sure the setter creates a deep copy of the input array.
        // Remove them before submitting.
        System.out.println("mergeSortMembers tests:");
        Member[] members = new Member[1];
        members[0] = new Member("Ken", Group.BACKEND, 9);
        Team team1 = new Team(members);
        team1.mergeSortMembers();
        for (int i = 0; i < team1.getMembers().length; i++) {
            System.out.println(team1.getMembers()[i]);
        }
        System.out.println();

        members = new Member[6];
        members[0] = new Member("Ken", Group.BACKEND, 9);
        members[1] = new Member("Erich", Group.BACKEND, 8);
        members[2] = new Member("Nathalie", Group.FRONTEND, 7);
        members[3] = new Member("Eman", Group.FRONTEND, 6);
        members[4] = new Member("Erich", Group.FRONTEND, 8);
        members[5] = new Member("Erich", Group.BACKEND, 10);
        team1.setMembers(members);
        team1.mergeSortMembers();
        for (int i = 0; i < team1.getMembers().length; i++) {
            System.out.println(team1.getMembers()[i]);
        }
        System.out.println();

        members = new Member[8];
        members[0] = new Member("Ken", Group.BACKEND, 9);
        members[1] = new Member("Erich", Group.BACKEND, 8);
        members[2] = new Member("Nathalie", Group.FRONTEND, 7);
        members[3] = new Member("Eman", Group.FRONTEND, 6);
        members[4] = new Member("Erich", Group.FRONTEND, 8);
        members[5] = new Member("Erich", Group.BACKEND, 10);
        members[6] = new Member("Ricky", Group.ADMIN, 12);
        members[7] = new Member("Joe", Group.ADMIN, 10);
        team1.setMembers(members);
        team1.mergeSortMembers();
        for (int i = 0; i < team1.getMembers().length; i++) {
            System.out.println(team1.getMembers()[i]);
        }
        System.out.println();

        System.out.println("mergeAllMembers test:");
        members = new Member[1];
        members[0] = new Member("Pat", Group.FRONTEND, 7);
        team1.setMembers(members);
        Member[][] membersTwoDim = {{new Member("Erich", Group.BACKEND, 8), new Member("Ken", Group.BACKEND, 9)},
                {new Member("Eman", Group.FRONTEND, 6), new Member("Klaus", Group.FRONTEND, 4), new Member("Frank", Group.ADMIN, 8)},
                {new Member("Harrison", Group.ADMIN, 11)}};
        team1.mergeAllMembers(membersTwoDim);
        for (int i = 0; i < team1.getMembers().length; i++) {
            System.out.println(team1.getMembers()[i]);
        }
        System.out.println();

        System.out.println("searchMember tests:");
        Member harrison = new Member("Harrison", Group.ADMIN, 11);
        System.out.println(team1.searchMember(harrison));
        System.out.println(team1.searchMember(harrison) == harrison);
        System.out.println(team1.searchMember(new Member("Eman", Group.FRONTEND, 6)));
        System.out.println(team1.searchMember(new Member("Pat", Group.FRONTEND, 7)));
        System.out.println();

        System.out.println("reverseMembers test:");
        System.out.println();
        Member[] reversed = team1.reverseMembers();
        System.out.println("Reversed Array:");
        for (int i = 0; i < reversed.length; i++) {
            System.out.println(reversed[i]);
        }
        System.out.println();
        System.out.println("Unchanged members array:");
        for (int i = 0; i < team1.getMembers().length; i++) {
            System.out.println(team1.getMembers()[i]);
        }
        System.out.println();

        System.out.println("selectLeaderboard tests:");
        ArrayList<Member> leaderboard = team1.selectLeaderboard();
        System.out.println(leaderboard.get(0));
        System.out.println(leaderboard.get(1));
        System.out.println();

        // All of the following commented lines should throw an exception. Uncomment and run one scenario at a time.
        // Recomment previous exceptional lines after running.
        members = new Member[3];
        members[0] = new Member("Member 1", Group.ADMIN, 9);
        members[1] = null;
        members[2] = new Member("Member 2", Group.ADMIN, 7);

        // Member[] members2 = null;
        // Team team2 = new Team(members2);

        // Team team2 = new Team(members);

        // System.out.println(team1.searchMember(new Member("asdnuqwef", Group.BACKEND, 30)));

        // System.out.println(team1.searchMember(null));

        members[1] = new Member("Admin", Group.ADMIN, 10);

        // team1.setMembers(members);
        // System.out.println(team1.selectLeaderboard());

        // members[2] = new Member("Member 2", Group.FRONTEND, 7);
        // team1.setMembers(members);
        // System.out.println(team1.selectLeaderboard());

        // members[2] = new Member("Member 2", Group.BACKEND, 7);
        // team1.setMembers(members);
        // System.out.println(team1.selectLeaderboard());
    }
}