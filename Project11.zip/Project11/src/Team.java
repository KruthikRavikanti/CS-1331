import java.util.ArrayList;
import java.util.NoSuchElementException;
/**
 * Team class.
 * @author kravikanti3
 * @version 1.0
 */
public class Team {
    public Member[] getMembers() {
        return members;
    }

    public void setMembers(Member[] members) {
        this.members = members;
    }

    private Member[] members;

    /**
     * Constructor taking in a members array and deep copying.
     * @param members Array being taken in.
     * @throws IllegalArgumentException Exception thrown.
     */
    public Team(Member[] members) throws IllegalArgumentException {
        if (members == null) {
            throw new IllegalArgumentException("Array is null! :(");
        }
        int x = members.length;
        this.members = new Member[x];

        for (int i = 0; i < x; i++) {
            if (members[i] == null) {
                throw new IllegalArgumentException("Array has null elements! :(");
            }
            this.members[i] = new Member(members[i]);
        }
    }

    /**
     * Method that performs the merge sort on the specific members array from the class.
     */
    public void mergeSortMembers() {
        members = sorty(members);
    }

    /**
     * Recursive helper method that takes in mem and sorts.
     * @param mem Array to be sorted.
     * @return Member[] is returned.
     */
    private Member[] sorty(Member[] mem) {
        int side = mem.length;
        if (!(mem.length > 1)) {
            return mem;
        }

        int middle = side / 2;
        Member[] lArr = HWUtils.copyOfRange(mem, 0, middle);
        Member[] rArr = HWUtils.copyOfRange(mem, middle, side);
        return HWUtils.merge(sorty(lArr), sorty(rArr));
    }

    /**
     * Calls method that is recursive later on merges all members.
     * @param large The 2-D array taken in.
     */
    public void mergeAllMembers(Member[][] large) {
        mergeSortMembers();
        for (int i = 0; i < large.length; i++) {
            Member[] small = large[i];
            members = HWUtils.merge(members, sorty(small));
        }
    }

    /**
     * Method that will search for a specific member by calling helper method that calls a recursive method.
     * @param s A member that is taken in to be searched.
     * @return A member is returned that was searched.
     * @throws IllegalArgumentException If arguments are not valid.
     */
    public Member searchMember(Member s) throws IllegalArgumentException {
        if (s == null) {
            throw new IllegalArgumentException("Member is null! :(");
        }

        mergeSortMembers();
        return sear(s, members);
    }

    /**
     * Calls recursive method that takes in a member and member array.
     * @param s A member object.
     * @param mem An array.
     * @return A specific member object is returned.
     */
    private Member sear(Member s, Member[] mem) {
        mem = sorty(mem);

        int st = 0;
        int term = mem.length - 1;

        while (st <= term) {
            int mid = st + (term - st) / 2;
            if (mem[mid].equals(s)) {
                return mem[mid];
            } else if (s.compareTo(mem[mid]) < 0) {
                term = mid - 1;
            } else {
                st = mid + 1;
            }
        }
        throw new NoSuchElementException("Element cannot be found! :(");
    }

    /**
     * A method that will reverse the members by calling a recursive helper method.
     * @return A member array is returned.
     */
    public Member[] reverseMembers() {
        int x = members.length;
        Member[] copy = new Member[x];
        for (int i = 0; i < x; i++) {
            copy[i] = new Member(members[i]);
        }
        lilRev(copy, 0, x - 1);
        return copy;
    }

    /**
     * Recursive helper method that supports reverse members method.
     * @param copy A member array taken in.
     * @param start The starting index.
     * @param end The ending index.
     */
    private void lilRev(Member[] copy, int start, int end) {
        if (!(start < end)) {
            return;
        } else {
            Member m = copy[start];
            copy[start] = copy[end];
            copy[end] = m;
            lilRev(copy, start + 1, end - 1);
        }
    }

    /**
     * A method that details about the leaderboard calls recursive helper method.
     * @return A list of members is returned.
     */
    public ArrayList<Member> selectLeaderboard() {
        ArrayList<Member> rList = new ArrayList<>();
        ArrayList<Member> fList = new ArrayList<>();
        ArrayList<Member> bList = new ArrayList<>();
        together(fList, bList, members);

        if (fList.isEmpty() || bList.isEmpty()) {
            throw new NoSuchElementException("Failed to select leaders for both subgroups.");
        }

        Member f = fList.get((int) (Math.random() * fList.size()));
        Member b = bList.get((int) ((Math.random() * bList.size())));

        if (f == null) {
            throw new NoSuchElementException("Failed to select a leader for the FRONTEND subgroup.");
        }

        if (b == null) {
            throw new NoSuchElementException("Failed to select a leader for the BACKEND subgroup.");
        }

        rList.add(f);
        rList.add(b);
        return rList;
    }

    /**
     * Recursive helper method that organizes the members as needed.
     * @param begin The first one,
     * @param behind The member in the back,
     * @param s A member array.
     */
    private void together(ArrayList<Member> begin, ArrayList<Member> behind, Member[] s) {
        if (s[0].getSubgroup().equals(Group.FRONTEND)) {
            begin.add(s[0]);
        }
        if (s[0].getSubgroup().equals(Group.BACKEND)) {
            behind.add(s[0]);
        }
        if (!(s.length <= 1)) {
            together(begin, behind, HWUtils.copyOfRange(s, 1, s.length));
        }
    }

}
