/**
 * Ride class.
 * @author kravikanti3
 * @version 1.0
 */
public abstract class Ride {
    protected final String id;
    protected double earnings;
    protected int runsSinceInspection;
    protected String[] passengers;

    /**
     * Constructor that makes a Ride object.
     * @param id The name of the Ride.
     * @param runsSinceInspection The runs a Ride can run till inspection.
     * @param passengers The list of passengers for the Ride.
     */
    public Ride(String id, int runsSinceInspection, String[] passengers) {
        this.id = id;
        this.runsSinceInspection = runsSinceInspection;
        this.passengers = new String[passengers.length];
        for (int i = 0; i < passengers.length; i++) {
            this.passengers[i] = passengers[i];
        }
        this.earnings = 0;
    }

    /**
     * Constructor that makes a Ride object.
     * @param id The name of the Ride.
     * @param passengers The list of passengers for the Ride.
     */
    public Ride(String id, String[] passengers) {
        this(id, 0, passengers);
    }

    /**
     * Abstract method returns boolean if ride can run.
     * @param runs Number of runs to be run.
     * @return boolean Can the ride run.
     */
    public abstract boolean canRun(int runs);

    /**
     * Abstract method returns boolean if ride has been inspected.
     * @param components String array showing the position of components.
     * @return boolean Has the ride been inspected.
     */
    public abstract boolean inspectRide(String[] components);

    /**
     * Abstract methods calculate charge for specified stops.
     * @param stops Number of stops.
     * @return double Cost per passenger.
     */
    public abstract double costPerPassenger(int stops);

    /**
     * Abstract method that will add specified passengers based on availability.
     * @param stops Number of stops.
     * @param list List given to be added.
     * @return boolean Have the passengers been added.
     */
    public abstract boolean addPassengers(int stops, String[] list);

    /**
     * Method puts the passengers on different lines from the list.
     * @return String Lists out all the passengers of the object.
     */
    public String getPassengerList() {
        String s = String.format("Passenger List for %s:", id);
        for (int i = 0; i < this.passengers.length; i++) {
            s += passengers[i] != null ? "\n" + this.passengers[i] : "";
        }
        return s;
    }

    /**
     * Method charges a passenger to the earnings.
     * @param stops Number of stops.
     */
    public void chargePassenger(int stops) {
        earnings += costPerPassenger(stops);
    }

    /**
     * Method removes a passenger that is requested.
     * @param name Name of the passenger to be removed.
     * @return boolean Has the passenger been removed.
     */
    public boolean removePassenger(String name) {
        for (int i = 0; i < passengers.length; i++) {
            if ((passengers[i].toUpperCase()).equals(name.toUpperCase()) && passengers[i] != null) {
                passengers[i] = null;
                return true;
            }
        }
        return false;
    }

    /**
     * Methods checks to see if two ride objects are equal to each other.
     * @param ride Object passed in.
     * @return boolean Are the objects equal to each other.
     */
    public boolean equals(Object ride) {
        if (ride == null) {
            return false;
        }
        if (!(ride.getClass().equals(this.getClass()))) {
            return false;
        }
        Ride ride1 = (Ride) ride;
        return id.toUpperCase().equals(ride1.id.toUpperCase()) && ride1.runsSinceInspection == runsSinceInspection;
    }

    /**
     * Method writes down the object's details.
     * @return String that lists attributes.
     */
    public String toString() {
        return String.format("%s has run %d times and has earned $%.2f.", id, runsSinceInspection, earnings);
    }

}
