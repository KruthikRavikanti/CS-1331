/**
 * Trolley class.
 * @author kravikanti3
 * @version 1.0
 */
public class Trolley extends Ride {

    private String[] stations;
    private int currentStation;

    /**
     * Constructor that makes a Trolley object.
     * @param id The name of the trolley.
     * @param runsSinceInspection The runs a trolley can run till inspection.
     * @param stations List of stations trolley goes to.
     * @param currentStation Index that the trolley is currently at.
     */
    public Trolley(String id, int runsSinceInspection, String[] stations, int currentStation) {
        super(id, runsSinceInspection, new String[20]);
        this.stations = new String[stations.length];
        for (int i = 0; i < stations.length; i++) {
            this.stations[i] = stations[i];
        }
        this.currentStation = currentStation;
    }

    /**
     * Constructor that makes a Trolley object.
     * @param id The name of the trolley.
     * @param stations List of stations trolley goes to.
     * @param currentStation Index that the trolley is currently at.
     */
    public Trolley(String id, String[] stations, int currentStation) {
        super(id, new String[20]);
        this.stations = new String[stations.length];
        for (int i = 0; i < stations.length; i++) {
            this.stations[i] = stations[i];
        }
        this.currentStation = currentStation;
    }
    @Override
    public boolean canRun(int runs) {
        if (runs < 0) {
            return false;
        }
        return true;
    }

    @Override
    public boolean inspectRide(String[] components) {
        for (String component : components) {
            if (component.toUpperCase().equals("GAS TANK NOT EMPTY")) {
                for (String component2 : components) {
                    if (component2.toUpperCase().equals("BRAKES OK")) {
                        runsSinceInspection = 0;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public double costPerPassenger(int stops) {
        return (stops * 3.00) / stations.length;
    }

    @Override
    public boolean addPassengers(int stops, String[] names) {
        int j = 0;
        if (!this.canRun(stops)) {
            return false;
        }
        for (int i = 0; i < this.passengers.length; i++) {
            if (this.passengers[i] == null) {
                this.passengers[i] = names[j];
                this.chargePassenger(stops);
                j++;
            }
            if (j == names.length) {
                break;
            }
        }
        this.moveTrolley(stops);
        return true;
    }

    /**
     * Method sets current station based on how many stops have been advanced, also changes runsSinceInspection.
     * @param advance The number of stops trolley should move forward.
     */
    public void moveTrolley(int advance) {
        runsSinceInspection = advance > 0 ?  runsSinceInspection + (currentStation + advance) / stations.length
                            : runsSinceInspection;
        currentStation = (currentStation + advance) % stations.length;
        currentStation = currentStation == stations.length ? 0 : currentStation;
    }

    @Override
    public String toString() {
        String s;
        int index = currentStation < stations.length - 1 ? currentStation + 1 : 1;
        s = String.format("Trolley %s has driven %d loops and has earned $%.2f. This trolley is at %s. Next up is %s.",
                            id, runsSinceInspection, Math.round(earnings * 100) / 100.00, stations[currentStation],
                            stations[index]);
        return s;
    }

    @Override
    public boolean equals(Object trol) {
        if (trol == null) {
            return false;
        }
        if (!(trol.getClass().equals(this.getClass()))) {
            return false;
        }
        Trolley trol1 = (Trolley) trol;
        return this.id.toUpperCase().equals(trol1.id.toUpperCase())
                    && trol1.runsSinceInspection == this.runsSinceInspection
                    && stationsEqual(trol1.stations) && trol1.currentStation == this.currentStation;
    }

    private boolean stationsEqual(String[] stat) {
        if (stations.length == stat.length) {
            for (int i = 0; i < stations.length; i++) {
                if (!stations[i].equalsIgnoreCase(stat[i])) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
}
