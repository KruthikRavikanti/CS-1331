/**
 * RollerCoaster class.
 * @author kravikanti3
 * @version 1.0
 */
public class RollerCoaster extends Ride {

    private double rate;
    private double photoFees;
    private int maxNumRuns;

    /**
     * Constructor that makes a RollerCoaster object.
     * @param id The name of the roller coaster.
     * @param runsSinceInspection The runs a roller coaster can run till inspection.
     * @param passengers The list of passengers for the ride.
     * @param rate The cost per passenger.
     * @param photoFees The mandatory fees for photos.
     * @param maxNumRuns Runs that can be run before inspection.
     */
    public RollerCoaster(String id, int runsSinceInspection, String[] passengers, double rate, double photoFees,
                         int maxNumRuns) {
        super(id, runsSinceInspection, passengers);
        this.rate = rate;
        this.photoFees = photoFees;
        this.maxNumRuns = maxNumRuns;
    }

    /**
     * Constructor that makes a RollerCoaster object.
     * @param id The name of the roller coaster.
     * @param runsSinceInspection The runs a roller coaster can run till inspection.
     * @param maxNumRuns Runs that can be run before inspection.
     */
    public RollerCoaster(String id, int runsSinceInspection, int maxNumRuns) {
        super(id, runsSinceInspection, new String[4]);
        this.rate = 10;
        this.photoFees = 15;
        this.maxNumRuns = maxNumRuns;
    }

    /**
     * Constructor that makes a RollerCoaster object.
     * @param id The name of the roller coaster.
     */
    public RollerCoaster(String id) {
        super(id, new String[4]);
        this.rate = 10;
        this.photoFees = 15;
        this.maxNumRuns = 200;
    }

    @Override
    public boolean canRun(int runs) {
        if (runsSinceInspection + runs > maxNumRuns || runs < 0) {
            return false;
        }
        return true;
    }

    @Override
    public boolean inspectRide(String[] components) {
        for (String component : components) {
            if (component.toUpperCase().equals("TRACKS CLEAR")) {
                for (String component2 : components) {
                    if (component2.toUpperCase().equals("BRAKES OK")) {
                        runsSinceInspection = 0;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public double costPerPassenger(int stops) {
        return stops * rate + photoFees;
    }

    @Override
    public boolean addPassengers(int stops, String[] list) {
        int j = 0;
        if (list.length > nullSeats(this.passengers) || runsSinceInspection + stops > maxNumRuns) {
            return false;
        }
        for (int i = 0; i < this.passengers.length; i++) {
            if (this.passengers[i] == null) {
                this.passengers[i] = list[j];
                this.chargePassenger(stops);
                j++;
            }
            if (j == list.length) {
                break;
            }
        }
        this.runsSinceInspection += stops;
        return true;
    }

    @Override
    public boolean equals(Object rolCos) {
        if (rolCos == null) {
            return false;
        }
        if (!(rolCos.getClass().equals(this.getClass()))) {
            return false;
        }
        RollerCoaster rolCos1 = (RollerCoaster) rolCos;
        return this.id.toUpperCase().equals(rolCos1.id.toUpperCase())
                && rolCos1.runsSinceInspection == this.runsSinceInspection && rolCos1.rate == this.rate
                && rolCos1.photoFees == this.photoFees && rolCos1.maxNumRuns == this.maxNumRuns;
    }

    @Override
    public String toString() {
        return String.format("Roller Coaster %s has run %d times and has earned $%.2f. It can only run %d more times. "
                            + "It costs $%.2f per ride and there is a one-time photo fee of $%.2f.", id,
                            runsSinceInspection, earnings, maxNumRuns - runsSinceInspection, rate, photoFees);
    }

    private double nullSeats(String[] pass) {
        int nullSeats = 0;
        for (int i = 0; i < pass.length; i++) {
            if (pass[i] == null) {
                nullSeats++;
            }
        }
        return nullSeats;
    }
}
