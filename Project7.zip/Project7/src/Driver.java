/**
 * Driver class.
 * @author kravikanti3
 * @version 1.0
 */
public class Driver {
    /**
     * Main method to test all the classes.
     * @param args of String
     */
    public static void main(String[] args) {
        boolean rollerCoaster, trolley, rolAdd, trolAdd;
        String[] stations = new String[] {"Midtown", "Cumming", "Five Points", "Buckhead"};
        String[] originalPassengers = new String[] {null, "drake", "france", null, null};
        String[] toBeAdded = new String[] {"Tony", "Jake", "Bob"};
        RollerCoaster kru = new RollerCoaster("Thunder", 0, originalPassengers, 10, 15, 200);
        RollerCoaster sane = new RollerCoaster("Thunder");
        System.out.println(kru);
        System.out.println(sane);
        rollerCoaster = kru.equals(sane);
        rolAdd = kru.addPassengers(5, toBeAdded);
        Trolley ava = new Trolley("Train", 0, stations, 2);
        Trolley man = new Trolley("Train", stations, 2);
        System.out.println(ava);
        System.out.println(man);
        trolley = ava.equals(man);
        rolAdd = ava.addPassengers(5, toBeAdded);
    }
}
