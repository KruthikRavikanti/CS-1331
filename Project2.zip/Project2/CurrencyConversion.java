public class CurrencyConversion {
    //My name is Kruthik Ravikanti, and I can do the splits.
    public static void main(String[] args){
        double aedPerUsd = 3.67;
        double aedPerEur = 4.19;
        int notes = 250;
        String name = "Nicolas";
        double euros = notes/aedPerEur;
        double dollars = notes/aedPerUsd;
        double eurosTrunc = (double) ((int) (euros * 100)) / 100;
        double dollarsTrunc = (double) ((int) (dollars * 100)) / 100;
        System.out.println(name + " is carrying " + eurosTrunc + " Euros and " + dollarsTrunc + " Dollars!");
    }
}
