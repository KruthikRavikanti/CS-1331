/**
 * Pterodactyl class, child of Dinosaur class.
 * @author kravikanti3
 * @version 1.0
 */
public class Pterodactyl extends Dinosaur {
    private double flightCeiling;

    /**
     * Constructor that creates a Pterodactyl object with a given name, height, width, weight, and flightCeiling.
     * @param name String as name for Pterodactyl object
     * @param height double as height for Pterodactyl object.
     * @param width double as width for Pterodactyl object.
     * @param weight double as weight for Pterodactyl object.
     * @param flightCeiling double as altitude height for Pterodactyl object.
     */
    public Pterodactyl(String name, double height, double width, double weight, double flightCeiling) {
        super(name, height, width, weight);
        if (flightCeiling >= 10 && flightCeiling <= 100) {
            this.flightCeiling = flightCeiling;
        } else {
            this.flightCeiling = 50;
        }
    }

    /**
     * Constructor that creates a Pterodactyl object with a given name and width with other attributed defaulting.
     * @param name String as name for Pterodactyl object
     * @param width double as width for Pterodactyl object.
     */
    public Pterodactyl(String name, double width) {
        super(name, 15, width, 1000);
        this.flightCeiling = 50;
    }

    /**
     * Constructor that creates a Pterodactyl object with a given name with other attributed defaulting.
     * @param name String as name for Pterodactyl object
     */
    public Pterodactyl(String name) {
        super(name, 15, 12, 1000);
        this.flightCeiling = 50;
    }

    /**
     * Constructor that creates a Pterodactyl object with parameters from another Pterodactyl object.
     * @param copyPer Pterodactyl object as copyPer used to copy attributes to new Pterodactyl object.
     */
    public Pterodactyl(Pterodactyl copyPer) {
        super(copyPer);
        this.flightCeiling = copyPer.flightCeiling;
    }

    /**
     * Method computes enclosure size for a Pterodactyl object using height, width, and flightCeiling.
     * @return double representing area for the enclosure of a dinosaur object.
     */
    @Override
    public double enclosureSize() {
        return (4 * getWidth() * getHeight()) + flightCeiling;
    }

    /**
     * Method for representing a specific Pterodactyl object as a String.
     * @return String that represents a Pterodactyl object by listing the attributes.
     */
    public String toString() {
        return String.format("%s can fly %.2f feet into the air! %s requires a %.2f square foot enclosure"
                        + " and %.2f pounds of food.",
                this.name,
                Math.round(this.flightCeiling * 100) / 100.00,
                this.name,
                Math.round(this.enclosureSize() * 100) / 100.00,
                Math.round(this.calculateFood() * 100) / 100.00);
    }

    /**
     * Getter for flightCeiling variable.
     * @return double representing altitude of flight for Pterodactyl.
     */
    public double getFlightCeiling() {

        return flightCeiling;
    }

    /**
     * Setter for flightCeiling variable.
     * @param flightCeiling double representing altitude of flight for Pterodactyl.
     */
    public void setFlightCeiling(double flightCeiling) {
        if (flightCeiling >= 10 && flightCeiling <= 100) {
            this.flightCeiling = flightCeiling;
        } else {
            this.flightCeiling = 50;
        }
    }

}
