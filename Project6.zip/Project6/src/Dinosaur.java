/**
 * Dinosaur class.
 * @author kravikanti3
 * @version 1.0
 */
public class Dinosaur {
    /**
     * Getter for name variable.
     * @return String representing name of dinosaur.
     */
    public String getName() {
        return name;
    }
    protected final String name;

    /**
     * Getter for height variable.
     * @return double representing height of dinosaur.
     */
    public double getHeight() {
        return height;
    }

    /**
     * Setter for height variable.
     * @param height double representing height of dinosaur.
     */
    public void setHeight(double height) {
        this.height = height;
    }
    private double height;

    /**
     * Getter for width variable.
     * @return double representing width of dinosaur.
     */
    public double getWidth() {
        return width;
    }

    /**
     * Setter for width variable.
     * @param width double representing width of dinosaur.
     */
    public void setWidth(double width) {
        this.width = width;
    }
    private double width;

    /**
     * Getter for weight variable.
     * @return double representing weight of dinosaur.
     */
    public double getWeight() {
        return weight;
    }

    /**
     * Setter for weight variable.
     * @param weight double representing weight of dinosaur.
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }
    private double weight;

    /**
     * Getter for totalEnclosures variable.
     * @return int representing totalEnclosures of dinosaur.
     */
    public static int getTotalEnclosures() {
        return totalEnclosures;
    }
    protected static int totalEnclosures;

    /**
     * Constructor that creates a dinosaur object with a given name, height, width, and weight.
     * @param name String as name for dinosaur object
     * @param height double as height for dinosaur object.
     * @param width double as width for dinosaur object.
     * @param weight double as weight for dinosaur object.
     */
    public Dinosaur(String name, double height, double width, double weight) {
        if (name == null || name.equals("") || name.equals(" ")) {
            this.name = "Barney";
        } else {
            this.name = name;
        }
        this.height = height;
        this.width = width;
        this.weight = weight;
    }

    /**
     * Constructor that creates a dinosaur object with default name, height, width, and weight.
     */
    public Dinosaur() {
        this.name = "Barney";
        this.height = 15;
        this.width = 20;
        this.weight = 1000;
    }

    /**
     * Constructor that creates a dinosaur object with parameters from another dinosaur object.
     * @param copyDin Dinosaur object as copyDin used to copy attributes to new dinosaur object.
     */
    public Dinosaur(Dinosaur copyDin) {
        this.height = copyDin.height;
        this.width = copyDin.width;
        this.weight = copyDin.weight;
        this.name = new String(copyDin.name);
    }

    /**
     * Method computes enclosure size for a dinosaur object using height and width.
     * @return Double representing area for the enclosure of a dinosaur object.
     */
    public double enclosureSize() {
        return 10 * width * height;
    }

    /**
     * Method computes food needed for a dinosaur object using height, width, and weight.
     * @return Double representing food in pounds a dinosaur object.
     */
    public double calculateFood() {
        return (weight * width) * height;
    }

    /**
     * Method for representing a specific dinosaur object as a String.
     * @return String that represents a dinosaur object by listing the attributes.
     */
    public String toString() {
        return String.format("%s requires a %.2f square foot enclosure and %.2f pounds of food.",
                name,
                Math.round(this.enclosureSize() * 100) / 100.00,
                Math.round(this.calculateFood() * 100) / 100.00);
    }

    /**
     * Methoh detailing if the construction of a enclosure is possible for a dinosaur object.
     * @return String listing specifications for a enclosure or listing why it cannot be built.
     */
    public String buildEnclosure() {
        if (this.enclosureSize() > 6000 || this.calculateFood() > 80000) {
            return String.format(this.toString() + " %s is too expensive for the park!", this.name);
        } else {
            totalEnclosures++;
            return String.format(this.toString() + " %s has been added to the park!", this.name);
        }
    }
}
