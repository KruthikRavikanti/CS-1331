/**
 * Pack class.
 * @author kravikanti3
 * @version 1.0
 */
public class Pack {

    private final int size;
    private final String packName;

    /**
     * Constructor that creates a pack object with a given size and packName.
     * @param size int as size for pack object
     * @param packName String as name for pack object.
     */
    public Pack(int size, String packName) {
        if (size < 0) {
            this.size = 4;
        } else {
            this.size = (int) size;
        }
        if (packName == null || packName.equals("") || packName.equals(" ")) {
            this.packName = "The Power Pack";
        } else {
            this.packName = packName;
        }
    }

    /**
     * Method for representing a specific pack object as a String.
     * @return String that represents a pack object by listing the attributes.
     */
    public String toString() {
        return String.format("%s is a family of dinosaurs of size %d!", packName, size);
    }

    /**
     * Getter for size variable.
     * @return int representing size of pack.
     */
    public int getSize() {
        return size;
    }

    /**
     * Getter for packName variable.
     * @return String representing name of pack.
     */
    public String getPackName() {
        return packName;
    }

}
