/**
 * Velociraptor class, child of Dinosaur class.
 * @author kravikanti3
 * @version 1.0
 */
public class Velociraptor extends Dinosaur {

    private int speed;

    private Pack pack;

    /**
     * Constructor that creates a Velociraptor object with a given name, height, width, weight, speed, and pack.
     * @param name String as name for Velociraptor object
     * @param height double as height for Velociraptor object.
     * @param width double as width for Velociraptor object.
     * @param weight double as weight for Velociraptor object.
     * @param speed int as speed for Velociraptor object which is adjusted depending on given input.
     * @param pack Pack as pack for Velociraptor object.
     */
    public Velociraptor(String name, double height, double width, double weight, int speed, Pack pack) {
        super(name, height, width, weight);
        if (speed < 0) {
            this.speed = 30;
        } else {
            this.speed = speed;
        }
        this.pack = pack;
    }

    /**
     * Constructor that creates a Velociraptor object with a given name and height with other attributed defaulting.
     * @param name String as name for Velociraptor object
     * @param height double as height for Velociraptor object.
     */
    public Velociraptor(String name, double height) {
        super(name, height, 20, 1000);
        this.speed = 30;
        this.pack = null;
    }

    /**
     * Constructor that creates a Velociraptor object with parameters from another Velociraptor object.
     * @param copyVel Velociraptor object as copyVel used to copy attributes to new Velociraptor object.
     */
    public Velociraptor(Velociraptor copyVel) {
        super(copyVel);
        this.speed = copyVel.speed;
        this.pack = copyVel.pack;
    }

    /**
     * Method computes amount of food for a Velociraptor object using height, speed, and weight.
     * @return double representing food in pounds of a Velociraptor object.
     */
    @Override
    public double calculateFood() {
        return getWeight() * speed * getHeight();
    }

    /**
     * Method computes enclosure size for a Velociraptor object using height, width, and size of pack if it applies.
     * @return double representing area for the enclosure of a Velociraptor object.
     */
    @Override
    public double enclosureSize() {
        if (this.pack != null) {
            return getWidth() * getHeight() * this.pack.getSize();
        } else {
            return 4 * getWidth() * getHeight();
        }
    }

    /**
     * Method for representing a specific Velociraptor object as a String.
     * @return String that represents a Velociraptor object by listing the attributes.
     */
    public String toString() {
        if (this.pack == null) {
            return String.format("%s requires a %.2f square foot enclosure and %.2f pounds of food.",
                    this.name,
                    Math.round(this.enclosureSize() * 100) / 100.00,
                    Math.round(this.calculateFood() * 100) / 100.00);
        } else {
            return String.format("%s is a family of dinosaurs of size %d! %s requires a %.2f square foot enclosure "
                            + "and %.2f pounds of food.",
                    this.pack.getPackName(),
                    this.pack.getSize(),
                    this.name,
                    Math.round(this.enclosureSize() * 100) / 100.00,
                    Math.round(this.calculateFood() * 100) / 100.00);
        }
    }


    /**
     * Getter for speed variable.
     * @return int representing speed of Velociraptor.
     */
    public int getSpeed() {
        return speed;
    }

    /**
     * Setter for speed variable.
     * @param speed double representing speed of Velociraptor.
     */
    public void setSpeed(int speed) {
        if (speed < 0) {
            this.speed = 30;
        } else {
            this.speed = speed;
        }
    }

    /**
     * Getter for pack variable.
     * @return Pack representing what pack a Pterodactyl object belongs to.
     */
    public Pack getPack() {
        return pack;
    }

    /**
     * Setter for pack variable.
     * @param pack Pack representing what pack a Pterodactyl object belongs to.
     */
    public void setPack(Pack pack) {
        this.pack = pack;
    }
}
