/**
 * Jurassic Park class.
 * @author kravikanti3
 * @version 1.0
 */
public class JurassicPark {
    /**
     * Main method to test all the classes.
     * @param args of String
     */
    public static void main(String[] args) {
        Pack ultimate = new Pack(20, "");
        Dinosaur kru = new Dinosaur();
        Dinosaur sanu = new Dinosaur(kru);
        Pterodactyl ava = new Pterodactyl("Bestie", 50.0, 90, 2, 60);
        Pterodactyl man = new Pterodactyl(ava);
        Velociraptor sud = new Velociraptor("yooo", 40, 10, 300, 19, ultimate);
        Velociraptor sho = new Velociraptor(sud);
        System.out.println(sud);
        System.out.println(sho);
        System.out.println(sho);
        System.out.println(kru.buildEnclosure());
        System.out.println(sanu.buildEnclosure());
        System.out.println(ava.buildEnclosure());
        System.out.println(man.buildEnclosure());
        System.out.println(sud.buildEnclosure());
        System.out.println(sho.buildEnclosure());
    }
}
