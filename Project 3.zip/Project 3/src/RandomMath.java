
import java.util.Scanner;
import java.util.Random;
public class RandomMath {
    public static void main (String[] args){
        /*System.out.println("1, Powers of a Number\n" +
                            "2, Random Positive Integer with Maximum\n" +
                            "3, Area of Random Circle\n" +
                            "4, Area of Random Square\n" +
                            "What would you like to do?");

        Scanner scan = new Scanner(System.in);
        Random random = new Random();
        int userInput = scan.nextInt();
        while (userInput<1 || userInput>4) {
            System.out.println("Invalid user input, type a number 1-4.");
            userInput = scan.nextInt();
        }

        if (userInput == 1) {
            System.out.print("What number would you like to calculate powers of? ");
            userInput = scan.nextInt();
            switch (userInput) {
                case -1: System.out.println("-1 raised to 0 is 1\n" +
                                            "-1 raised to odd powers greater than 0 is -1\n" +
                                            "-1 raised to even powers greater than 0 is 1");
                         break;
                case 0: System.out.println("0 raised to the 0 is 1\n" +
                                           "0 raised to powers greater than 0 is 0");
                         break;
                case 1: System.out.println("1 raised to ANY power is still 1");
                         break;
                default: int i=0;
                         do {
                             System.out.printf("%d raised to the %d is %d.\n", userInput, i, (int)Math.pow(userInput,i));
                             i++;
                         } while ((int)Math.abs(Math.pow(userInput,i))<100);
            }
        }
        else if (userInput == 2) {
            System.out.print("What is the max value you want your random number to be? ");
            userInput = scan.nextInt();
            if (userInput < 1) {
                System.out.println("User input must be positive and non-zero.");
            }
            else {
                int randomNumber = random.nextInt(userInput) + 1;
                System.out.printf("Your random number is %d.", randomNumber);
            }

        }
        else if (userInput == 3) {
            int circleRadius = random.nextInt(101);
            double circleArea = Math.pow(circleRadius, 2)*Math.PI;
            System.out.printf("A circle of radius %d has an area of %.2f.", circleRadius, Math.round(circleArea*100)/100.0);
        }
        else {
            int sideLength = (int) (Math.random()*101);
            int squareArea = (int)Math.pow(sideLength,2);
            System.out.printf("A square of side length %d has an area of %d.", sideLength, squareArea);
        }*/
        Scanner s = new Scanner(System.in);
        System.out.print("Age: ");
        int age = s.nextInt();
        System.out.print("Name: ");
        String lol = s.nextLine();
        System.out.printf("Welcome %s, you are %d this year!", lol, age);
    }
}
